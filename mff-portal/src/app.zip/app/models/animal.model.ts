export interface Animal {
  id: number;
  nomePopular: string;
  nomeCientifico: string;
  grupo: string; 
  habitat: string;
  dieta: string;
  curiosidade: string;
  imagem?: string;
}